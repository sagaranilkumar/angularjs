(function() {

  var app = angular.module('directivesModule', []);

  app.directive('linkDemo', function () {
      return {

      };
  });

}());

