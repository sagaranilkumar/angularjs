(function() {



  angular.module('directivesModule', [])
    .directive('mapGeoLocation', mapGeoLocation);

}());
